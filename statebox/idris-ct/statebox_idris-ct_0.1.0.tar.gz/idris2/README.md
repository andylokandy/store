
# Idris-ct Idris2 version

## Build

- Move into `idris2` subdirectory.
- Run `idris2 --build idris-ct.ipkg`

